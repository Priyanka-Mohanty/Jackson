package com.example.priyankam.jacksonexample;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;


import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends Activity {

    TextView textJson,textName,textAge;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context=getApplicationContext();
        textJson=(TextView)findViewById(R.id.text_json);
        textName=(TextView)findViewById(R.id.text_name);
        textAge=(TextView)findViewById(R.id.text_age);

        ObjectMapper mapper = new ObjectMapper();
        String jsonString;

        //map json to student

        try{

            Student student = mapper.readValue(loadJSONFromAsset(context), Student.class);

            System.out.println(student);

            mapper.enable(SerializationConfig.Feature.INDENT_OUTPUT);

            jsonString = mapper.writeValueAsString(student);

            System.out.println(jsonString);

            textJson.setText("Json = " + jsonString);
            textName.setText("Name = " + student.getName());
            textAge.setText("Age = " + student.getAge());
        }

        catch (JsonParseException e) { e.printStackTrace();}
        catch (JsonMappingException e) { e.printStackTrace(); }
        catch (IOException e) { e.printStackTrace(); }
    }
    public static String loadJSONFromAsset(Context context) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            InputStream is = context.getAssets().open("Student.json");
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is));


            String line;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line);
            }

            bufferedReader.close();
            return stringBuilder.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }

        return null;
    }
}